/**
 * NeuralHire – legacy entry (use src/App.jsx)
 * The app is now organized under src/. Run: npm run dev
 */
export { default } from "./src/App.jsx";
