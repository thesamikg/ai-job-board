import { useApp } from "../contexts/AppContext";
import { JobCard, JobDetail, EmailModal } from "../components/job";
import Navbar from "../components/layout/Navbar";
import { Toast } from "../components/ui";

export default function DashboardPage() {
  // Uses savedJobObjects directly from context — no local re-filtering of SAMPLE_JOBS
  const {
    savedJobs, savedJobObjects, emails, handleSave,
    selectedJob, setSelectedJob, applyJob, setApplyJob,
    handleApplySubmit, toast, setPage,
  } = useApp();

  const bg = { background: "#060b18", minHeight: "100vh", fontFamily: "'DM Sans', sans-serif", color: "#94a3b8" };

  return (
    <div style={bg}>
      <Navbar />
      <div style={{ maxWidth: 800, margin: "0 auto", padding: "80px 16px 60px" }}>
        <h1 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(22px,5vw,28px)", fontWeight: 800, color: "#f1f5f9", marginBottom: 6 }}>Dashboard</h1>
        <p style={{ fontSize: 14, color: "#64748b", marginBottom: 32 }}>Manage your saved jobs and preferences</p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 32 }}>
          {[["📌", savedJobs.length, "Saved Jobs"], ["📧", emails.length, "Applications"], ["🔔", "Active", "Job Alerts"]].map(([icon, val, label]) => (
            <div key={label} style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "16px 14px" }}>
              <div style={{ fontSize: 20, marginBottom: 6 }}>{icon}</div>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(18px,5vw,24px)", fontWeight: 800, color: "#f1f5f9", marginBottom: 2 }}>{val}</div>
              <div style={{ fontSize: 11, color: "#64748b" }}>{label}</div>
            </div>
          ))}
        </div>

        <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: 16, fontWeight: 700, color: "#e2e8f0", marginBottom: 14 }}>Saved Jobs</h3>
        {savedJobObjects.length === 0 ? (
          <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "40px 20px", textAlign: "center" }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>☆</div>
            <div style={{ fontSize: 14, color: "#64748b", marginBottom: 16 }}>No saved jobs yet. Browse jobs and save the ones you like.</div>
            <button onClick={() => setPage("jobs")} style={{ padding: "10px 20px", background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.4)", borderRadius: 8, color: "#a78bfa", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>Browse Jobs</button>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {savedJobObjects.map(job => (
              <JobCard key={job.id} job={job} onClick={j => setSelectedJob(j)} saved={true} onSave={handleSave} />
            ))}
          </div>
        )}
      </div>
      {selectedJob && <JobDetail job={selectedJob} onClose={() => setSelectedJob(null)} onApply={j => { setApplyJob(j); setSelectedJob(null); }} saved={savedJobs.includes(selectedJob.id)} onSave={handleSave} />}
      {applyJob && <EmailModal job={applyJob} onClose={() => setApplyJob(null)} onSubmit={handleApplySubmit} />}
      <Toast message={toast.message} visible={toast.visible} />
    </div>
  );
}
