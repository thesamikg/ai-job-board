import { useState } from "react";
import { useApp } from "../contexts/AppContext";
import { JobCard, JobDetail, EmailModal } from "../components/job";
import Navbar from "../components/layout/Navbar";
import { Toast } from "../components/ui";
import { ALL_SKILLS } from "../data/jobs";

export default function JobsPage() {
  const {
    filteredJobs, savedJobs, handleSave,
    selectedJob, setSelectedJob, applyJob, setApplyJob, handleApplySubmit,
    search, setSearch, filters, setFilters, toast,
  } = useApp();

  const [filtersOpen, setFiltersOpen] = useState(false);
  const bg = { background: "#060b18", minHeight: "100vh", fontFamily: "'DM Sans', sans-serif", color: "#94a3b8" };
  const activeFilterCount = (filters.remote ? 1 : 0) + (filters.exp ? 1 : 0) + filters.skills.length;

  const FilterContent = () => (
    <>
      <button className="filter-close-btn" onClick={() => setFiltersOpen(false)}
        style={{ position: "fixed", top: 16, right: 20, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "6px 12px", color: "#94a3b8", cursor: "pointer", fontSize: 14, zIndex: 501, display: "none", alignItems: "center", gap: 6 }}>
        ✕ Close
      </button>
      <h3 style={{ fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 700, color: "#e2e8f0", marginBottom: 20 }}>Filters</h3>
      <div style={{ marginBottom: 24 }}>
        <h4 style={{ fontSize: 11, color: "#64748b", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 12 }}>Work Mode</h4>
        <label style={{ display: "flex", gap: 10, alignItems: "center", cursor: "pointer" }}>
          <input type="checkbox" checked={filters.remote} onChange={e => setFilters(f => ({ ...f, remote: e.target.checked }))} style={{ accentColor: "#7c3aed" }} />
          <span style={{ fontSize: 13, color: "#94a3b8" }}>Remote only</span>
        </label>
      </div>
      <div style={{ marginBottom: 24 }}>
        <h4 style={{ fontSize: 11, color: "#64748b", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 12 }}>Experience</h4>
        {[["0-2", "0–2 yrs"], ["2-5", "2–5 yrs"], ["5+", "5+ yrs"]].map(([val, label]) => (
          <label key={val} style={{ display: "flex", gap: 10, alignItems: "center", cursor: "pointer", marginBottom: 8 }}>
            <input type="radio" name="exp" checked={filters.exp === val} onChange={() => setFilters(f => ({ ...f, exp: val }))} style={{ accentColor: "#7c3aed" }} />
            <span style={{ fontSize: 13, color: "#94a3b8" }}>{label}</span>
          </label>
        ))}
        {filters.exp && <button onClick={() => setFilters(f => ({ ...f, exp: "" }))} style={{ fontSize: 11, color: "#7c3aed", background: "transparent", border: "none", cursor: "pointer", marginTop: 4 }}>Clear</button>}
      </div>
      <div>
        <h4 style={{ fontSize: 11, color: "#64748b", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 12 }}>Skills</h4>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {ALL_SKILLS.map(skill => (
            <label key={skill} style={{ display: "flex", gap: 10, alignItems: "center", cursor: "pointer" }}>
              <input type="checkbox" checked={filters.skills.includes(skill)}
                onChange={e => setFilters(f => ({ ...f, skills: e.target.checked ? [...f.skills, skill] : f.skills.filter(s => s !== skill) }))}
                style={{ accentColor: "#7c3aed" }} />
              <span style={{ fontSize: 13, color: "#94a3b8" }}>{skill}</span>
            </label>
          ))}
        </div>
      </div>
      <button className="filter-close-btn" onClick={() => setFiltersOpen(false)}
        style={{ marginTop: 32, width: "100%", padding: "13px", background: "linear-gradient(135deg, #7c3aed, #2563eb)", border: "none", borderRadius: 10, color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Syne', sans-serif", display: "none" }}>
        Apply Filters ({filteredJobs.length} results)
      </button>
    </>
  );

  return (
    <div style={bg}>
      <Navbar />
      <div style={{ paddingTop: 60 }}>
        <div style={{ background: "rgba(6,11,24,0.9)", backdropFilter: "blur(20px)", borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "12px 16px", display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input value={search.title} onChange={e => setSearch(s => ({ ...s, title: e.target.value }))}
            placeholder="Search roles, companies, skills…" style={{ flex: "2 1 160px", padding: "10px 14px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#f1f5f9", fontSize: 14, outline: "none" }} />
          <input value={search.location} onChange={e => setSearch(s => ({ ...s, location: e.target.value }))}
            placeholder="Location…" style={{ flex: "1 1 100px", padding: "10px 14px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#f1f5f9", fontSize: 14, outline: "none" }} />
          <select value={filters.sort} onChange={e => setFilters(f => ({ ...f, sort: e.target.value }))} style={{ padding: "10px 12px", background: "#0f172a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 10, color: "#94a3b8", fontSize: 13, outline: "none", cursor: "pointer" }}>
            <option value="newest">Newest</option>
            <option value="salary">Salary ↑</option>
            <option value="remote">Remote</option>
          </select>
          <button className="filter-toggle-btn" onClick={() => setFiltersOpen(true)}
            style={{ padding: "10px 14px", background: activeFilterCount > 0 ? "rgba(124,58,237,0.2)" : "rgba(255,255,255,0.05)", border: `1px solid ${activeFilterCount > 0 ? "rgba(124,58,237,0.5)" : "rgba(255,255,255,0.1)"}`, borderRadius: 10, color: activeFilterCount > 0 ? "#a78bfa" : "#94a3b8", cursor: "pointer", fontSize: 13, fontWeight: 600, display: "none", alignItems: "center", gap: 6 }}>
            ⚙ Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ""}
          </button>
        </div>

        <div style={{ display: "flex", maxWidth: 1100, margin: "0 auto", padding: "20px 16px", gap: 20 }}>
          <div className={`sidebar-filters${filtersOpen ? " open" : ""}`} style={{ width: 200, flexShrink: 0 }}>
            <div style={{ position: "sticky", top: 80 }}><FilterContent /></div>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ marginBottom: 14 }}>
              <span style={{ fontSize: 13, color: "#64748b" }}><span style={{ color: "#e2e8f0", fontWeight: 700 }}>{filteredJobs.length}</span> jobs found</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {filteredJobs.length === 0 ? (
                <div style={{ textAlign: "center", padding: "60px 20px" }}>
                  <div style={{ fontSize: 40, marginBottom: 16 }}>🔍</div>
                  <div style={{ fontSize: 16, color: "#64748b", marginBottom: 16 }}>No jobs match your filters</div>
                  <button onClick={() => setFilters({ remote: false, skills: [], exp: "", sort: "newest" })} style={{ padding: "8px 18px", background: "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.4)", borderRadius: 8, color: "#a78bfa", cursor: "pointer", fontSize: 13 }}>Clear Filters</button>
                </div>
              ) : filteredJobs.map(job => (
                <JobCard key={job.id} job={job} onClick={j => setSelectedJob(j)} saved={savedJobs.includes(job.id)} onSave={handleSave} />
              ))}
            </div>
          </div>
        </div>
      </div>
      {selectedJob && <JobDetail job={selectedJob} onClose={() => setSelectedJob(null)} onApply={j => { setApplyJob(j); setSelectedJob(null); }} saved={savedJobs.includes(selectedJob.id)} onSave={handleSave} />}
      {applyJob && <EmailModal job={applyJob} onClose={() => setApplyJob(null)} onSubmit={handleApplySubmit} />}
      <Toast message={toast.message} visible={toast.visible} />
    </div>
  );
}
