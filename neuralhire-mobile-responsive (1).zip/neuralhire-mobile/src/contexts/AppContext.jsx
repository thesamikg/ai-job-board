import { createContext, useContext, useState, useCallback } from "react";
import { SAMPLE_JOBS } from "../data/jobs";
import { filterAndSortJobs } from "../utils/filterJobs";
import { useToast } from "../hooks/useToast";
import { useSavedJobs } from "../hooks/useSavedJobs";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  // Navigation
  const [page, setPage] = useState("home");

  // Job modals
  const [selectedJob, setSelectedJob] = useState(null);
  const [applyJob, setApplyJob] = useState(null);

  // Applications log
  const [emails, setEmails] = useState([]);

  // Search & filters
  const [search, setSearch] = useState({ title: "", location: "" });
  const [filters, setFilters] = useState({ remote: false, skills: [], exp: "", sort: "newest" });

  // Subscribe
  const [emailInput, setEmailInput] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  // Auth
  const [user, setUser] = useState(null);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginSent, setLoginSent] = useState(false);

  // Toast (custom hook)
  const { toast, showToast } = useToast();

  // Saved jobs (custom hook — depends on showToast)
  const { savedJobs, handleSave } = useSavedJobs(showToast);

  // Derived: saved job objects (fixes DashboardPage data flow issue)
  const savedJobObjects = SAMPLE_JOBS.filter(j => savedJobs.includes(j.id));

  // Derived: filtered jobs
  const filteredJobs = filterAndSortJobs(SAMPLE_JOBS, search, filters);

  // Apply handler
  const handleApplySubmit = useCallback((email, job) => {
    setEmails(prev => [...prev, { email, jobId: job.id, at: new Date() }]);
    setApplyJob(null);
    showToast("✓ Redirecting to application...");
    setTimeout(() => window.open(job.apply_url, "_blank"), 500);
  }, [showToast]);

  // Login handler
  const handleLogin = useCallback(() => {
    if (!loginEmail.includes("@")) return;
    setUser({ email: loginEmail });
    setLoginSent(true);
    setTimeout(() => { setPage("jobs"); showToast("✓ Welcome back!"); }, 1000);
  }, [loginEmail, showToast]);

  return (
    <AppContext.Provider value={{
      // Navigation
      page, setPage,
      // Job modals
      selectedJob, setSelectedJob,
      applyJob, setApplyJob,
      // Jobs data
      filteredJobs,
      savedJobs,
      savedJobObjects,
      handleSave,
      handleApplySubmit,
      // Applications
      emails,
      // Toast
      toast, showToast,
      // Search & filters
      search, setSearch,
      filters, setFilters,
      // Subscribe
      emailInput, setEmailInput,
      subscribed, setSubscribed,
      // Auth
      user,
      loginEmail, setLoginEmail,
      loginSent,
      handleLogin,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
