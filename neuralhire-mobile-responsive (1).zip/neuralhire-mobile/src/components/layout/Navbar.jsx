import { useState } from "react";
import { useApp } from "../../contexts/AppContext";
import { Logo } from "../ui";

export default function Navbar() {
  const { page, setPage, user } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: "rgba(6,11,24,0.92)", backdropFilter: "blur(20px)",
      borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "0 20px",
      display: "flex", alignItems: "center", justifyContent: "space-between", height: 60,
    }}>
      <div onClick={() => { setPage("home"); setMenuOpen(false); }} style={{ cursor: "pointer" }}>
        <Logo />
      </div>

      {/* Desktop nav */}
      <div id="desktop-nav" style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <style>{`@media(max-width:640px){#desktop-nav{display:none!important}}`}</style>
        {[["Jobs", "jobs"], ["Dashboard", "dashboard"]].map(([label, p]) => (
          <button key={p} onClick={() => setPage(p)} style={{
            background: page === p ? "rgba(124,58,237,0.15)" : "transparent",
            border: `1px solid ${page === p ? "rgba(124,58,237,0.4)" : "transparent"}`,
            borderRadius: 8, padding: "6px 16px", color: page === p ? "#a78bfa" : "#64748b",
            cursor: "pointer", fontSize: 13, fontWeight: 600, transition: "all 0.15s"
          }}>{label}</button>
        ))}
        {user ? (
          <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #2563eb)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: "#fff", marginLeft: 8 }}>
            {user.email[0].toUpperCase()}
          </div>
        ) : (
          <button onClick={() => setPage("login")} style={{ marginLeft: 8, background: "linear-gradient(135deg, #7c3aed, #2563eb)", border: "none", borderRadius: 8, padding: "7px 18px", color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 700, fontFamily: "'Syne', sans-serif" }}>Sign In</button>
        )}
      </div>

      {/* Mobile hamburger */}
      <button id="hamburger" onClick={() => setMenuOpen(!menuOpen)}
        style={{ background: "transparent", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "6px 10px", cursor: "pointer", color: "#94a3b8", fontSize: 18, lineHeight: 1, display: "none" }}>
        <style>{`@media(max-width:640px){#hamburger{display:flex!important;align-items:center;}}`}</style>
        {menuOpen ? "✕" : "☰"}
      </button>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ position: "fixed", top: 60, left: 0, right: 0, background: "#0b1120", borderBottom: "1px solid rgba(255,255,255,0.08)", padding: "16px 20px", display: "flex", flexDirection: "column", gap: 8, zIndex: 99 }}>
          {[["🏠 Home", "home"], ["💼 Jobs", "jobs"], ["📌 Dashboard", "dashboard"]].map(([label, p]) => (
            <button key={p} onClick={() => { setPage(p); setMenuOpen(false); }} style={{ background: page === p ? "rgba(124,58,237,0.15)" : "rgba(255,255,255,0.03)", border: `1px solid ${page === p ? "rgba(124,58,237,0.4)" : "rgba(255,255,255,0.06)"}`, borderRadius: 10, padding: "12px 16px", color: page === p ? "#a78bfa" : "#94a3b8", cursor: "pointer", fontSize: 14, fontWeight: 600, textAlign: "left" }}>{label}</button>
          ))}
          {!user ? (
            <button onClick={() => { setPage("login"); setMenuOpen(false); }} style={{ background: "linear-gradient(135deg, #7c3aed, #2563eb)", border: "none", borderRadius: 10, padding: "12px 16px", color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 700, fontFamily: "'Syne', sans-serif" }}>Sign In ✨</button>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0" }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #2563eb)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: "#fff" }}>{user.email[0].toUpperCase()}</div>
              <span style={{ fontSize: 13, color: "#94a3b8" }}>{user.email}</span>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
