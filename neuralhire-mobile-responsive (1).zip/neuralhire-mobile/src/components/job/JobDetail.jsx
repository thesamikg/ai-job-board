import { Badge, SkillTag } from "../ui";
import { timeSince, isNew, isHot, formatSalary } from "../../utils/jobHelpers";

export default function JobDetail({ job, onClose, onApply, saved, onSave }) {
  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(12px)",
      display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 900, padding: 0,
    }} onClick={onClose}>
      <style>{`
        @media(min-width:640px){
          .job-detail-modal { align-self: center !important; border-radius: 20px !important; max-height: 88vh !important; margin: 20px !important; }
        }
        @media(max-width:639px){
          .job-detail-modal { border-radius: 20px 20px 0 0 !important; max-height: 92vh !important; width: 100% !important; }
        }
      `}</style>
      <div onClick={e => e.stopPropagation()} className="job-detail-modal" style={{
        background: "#0b1120", border: "1px solid rgba(255,255,255,0.08)",
        maxWidth: 680, width: "100%", overflow: "auto",
        boxShadow: "0 32px 80px rgba(0,0,0,0.7)",
      }}>
        <div style={{ padding: "24px 24px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16, gap: 12 }}>
            <div style={{ display: "flex", gap: 14, alignItems: "flex-start", flex: 1, minWidth: 0 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 12, flexShrink: 0,
                background: "linear-gradient(135deg, rgba(124,58,237,0.4), rgba(37,99,235,0.4))",
                border: "1px solid rgba(255,255,255,0.1)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 14, fontWeight: 800, color: "#c4b5fd",
              }}>{job.companyLogo}</div>
              <div style={{ minWidth: 0 }}>
                <h2 style={{ fontFamily: "'Syne', sans-serif", fontSize: "clamp(16px,4vw,22px)", fontWeight: 800, color: "#f1f5f9", marginBottom: 4, lineHeight: 1.2 }}>{job.title}</h2>
                <div style={{ fontSize: 13, color: "#94a3b8" }}>{job.company} · {job.location}</div>
              </div>
            </div>
            <button onClick={onClose} style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "6px 12px", color: "#64748b", cursor: "pointer", fontSize: 16, flexShrink: 0, alignSelf: "flex-start" }}>✕</button>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {isNew(job.posted_at) && <Badge color="#22c55e">New</Badge>}
            {isHot(job) && <Badge color="#f97316">Hot</Badge>}
            {job.featured && <Badge color="#a78bfa">Featured</Badge>}
            <span style={{ fontSize: 12, color: "#64748b" }}>📍 {job.remote ? "Remote" : "On-site"}</span>
            <span style={{ fontSize: 12, color: "#64748b" }}>· {job.job_type} · {job.experience_level} yrs exp</span>
          </div>
        </div>

        <div style={{ padding: "20px 24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 24 }}>
            {[["💰 Salary", formatSalary(job)], ["📅 Posted", timeSince(job.posted_at)], ["🏢 Company", job.company], ["🎯 Type", job.job_type]].map(([label, val]) => (
              <div key={label} style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 10, padding: "12px 14px" }}>
                <div style={{ fontSize: 10, color: "#64748b", marginBottom: 3, fontWeight: 600, letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</div>
                <div style={{ fontSize: 13, color: "#e2e8f0", fontWeight: 600 }}>{val}</div>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: 20 }}>
            <h4 style={{ fontSize: 11, color: "#64748b", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 10 }}>Skills Required</h4>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {job.skills.map(s => <SkillTag key={s} skill={s} />)}
            </div>
          </div>

          <div style={{ marginBottom: 24 }}>
            <h4 style={{ fontSize: 11, color: "#64748b", fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 10 }}>About This Role</h4>
            <p style={{ fontSize: 14, color: "#94a3b8", lineHeight: 1.8 }}>{job.description}</p>
          </div>

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => onApply(job)} style={{
              flex: 1, padding: "13px 20px",
              background: "linear-gradient(135deg, #7c3aed, #2563eb)",
              border: "none", borderRadius: 12, color: "#fff", fontSize: 15, fontWeight: 700,
              cursor: "pointer", fontFamily: "'Syne', sans-serif",
            }}>Apply Now →</button>
            <button onClick={() => onSave(job.id)} style={{
              padding: "13px 18px",
              background: saved ? "rgba(124,58,237,0.15)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${saved ? "rgba(124,58,237,0.5)" : "rgba(255,255,255,0.1)"}`,
              borderRadius: 12, color: saved ? "#a78bfa" : "#64748b", fontSize: 15, cursor: "pointer"
            }}>{saved ? "★" : "☆"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}
