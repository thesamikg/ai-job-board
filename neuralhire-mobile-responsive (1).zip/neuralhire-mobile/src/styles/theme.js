// Shared design tokens — single source of truth for all inline styles

export const colors = {
  bg: "#060b18",
  surface: "rgba(255,255,255,0.02)",
  surfaceHover: "rgba(255,255,255,0.04)",
  border: "rgba(255,255,255,0.07)",
  borderHover: "rgba(255,255,255,0.12)",
  purple: "#7c3aed",
  purpleLight: "#a78bfa",
  purpleBg: "rgba(124,58,237,0.15)",
  purpleBorder: "rgba(124,58,237,0.4)",
  blue: "#2563eb",
  text: "#f1f5f9",
  textMuted: "#94a3b8",
  textDim: "#64748b",
  textDimmer: "#334155",
  green: "#22c55e",
  orange: "#f97316",
};

export const gradients = {
  brand: "linear-gradient(135deg, #7c3aed, #2563eb)",
  brandRadial: "radial-gradient(circle, rgba(124,58,237,0.3), rgba(37,99,235,0.3))",
  topLine: "linear-gradient(90deg, transparent, #7c3aed, #2563eb, transparent)",
};

export const card = {
  background: colors.surface,
  border: `1px solid ${colors.border}`,
  borderRadius: 14,
  padding: "20px 24px",
};

export const cardSm = {
  ...card,
  padding: "16px 18px",
  borderRadius: 12,
};

export const input = {
  background: "rgba(255,255,255,0.05)",
  border: `1px solid rgba(255,255,255,0.1)`,
  borderRadius: 10,
  color: colors.text,
  fontSize: 14,
  outline: "none",
  padding: "11px 14px",
};

export const btnPrimary = {
  background: gradients.brand,
  border: "none",
  borderRadius: 10,
  color: "#fff",
  cursor: "pointer",
  fontFamily: "'Syne', sans-serif",
  fontSize: 14,
  fontWeight: 700,
  padding: "12px 24px",
};

export const btnGhost = {
  background: "transparent",
  border: `1px solid rgba(255,255,255,0.08)`,
  borderRadius: 10,
  color: colors.textDim,
  cursor: "pointer",
  fontSize: 13,
  padding: "10px 20px",
};

export const font = {
  body: "'DM Sans', sans-serif",
  heading: "'Syne', sans-serif",
};
