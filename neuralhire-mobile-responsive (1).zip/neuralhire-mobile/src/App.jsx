import { AppProvider, useApp } from "./contexts/AppContext";
import { HomePage, JobsPage, DashboardPage, LoginPage } from "./pages";
import "./styles/global.css";

function AppRouter() {
  const { page } = useApp();
  if (page === "home") return <HomePage />;
  if (page === "jobs") return <JobsPage />;
  if (page === "dashboard") return <DashboardPage />;
  if (page === "login") return <LoginPage />;
  return null;
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
