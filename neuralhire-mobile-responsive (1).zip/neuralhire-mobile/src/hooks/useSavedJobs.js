import { useState, useCallback } from "react";

export function useSavedJobs(showToast) {
  const [savedJobs, setSavedJobs] = useState([]);

  const handleSave = useCallback((jobId) => {
    setSavedJobs(prev => {
      const isSaving = !prev.includes(jobId);
      showToast(isSaving ? "✓ Job saved to your dashboard" : "Job removed from saved");
      return isSaving ? [...prev, jobId] : prev.filter(id => id !== jobId);
    });
  }, [showToast]);

  return { savedJobs, handleSave };
}
