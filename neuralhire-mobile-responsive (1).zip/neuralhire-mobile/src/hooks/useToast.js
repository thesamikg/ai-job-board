import { useState, useCallback } from "react";

export function useToast() {
  const [toast, setToast] = useState({ message: "", visible: false });

  const showToast = useCallback((msg) => {
    setToast({ message: msg, visible: true });
    setTimeout(() => setToast(t => ({ ...t, visible: false })), 3000);
  }, []);

  return { toast, showToast };
}
